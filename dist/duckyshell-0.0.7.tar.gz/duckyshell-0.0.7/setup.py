from setuptools import setup

setup(
    name='duckyshell',
    version='0.0.7',
    description='Hak5 USB Rubber Ducky CLI',
    author='Daniel Boye',
    author_email='danielboye888@gmail.com',
    url='https://github.com/DanielBoye/duckyshell',
    package_dir={'': 'duckyshell'},
    scripts=['duckyshell/duckyshell.py'],

)
