# ducky-cli

---

One ducky program that is a command line program published as a python application
I want the input "ducky" to be global as when downloading metasploit (msfconsole)

~$ ducky

(ducky) path /mnt/usb (can also do this globaly with a yaml file maybe?)
(ducky) file /home/user/Downloads/file.txt
(ducky) run

---

One as a straight command line tool, published as a python package


List current connected USB, so the user does not need to provide/set new path for the usb

I think this is the one I am going to end up to use

Will be used for final project for CS50
